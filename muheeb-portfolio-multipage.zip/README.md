# Muheeb Portfolio (Multi-page Structure)

Pages:
- index.html
- about.html
- services.html
- results.html
- insights.html
- ventures.html
- contact.html

Upload the contents of this folder directly to GitHub.

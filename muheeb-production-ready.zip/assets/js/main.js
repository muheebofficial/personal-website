
// ===== CURSOR =====
const cursor = document.getElementById('cursor');
const ring = document.getElementById('cursorRing');
let mx = 0, my = 0, rx = 0, ry = 0;

document.addEventListener('mousemove', e => {
  mx = e.clientX; my = e.clientY;
  cursor.style.left = mx + 'px'; cursor.style.top = my + 'px';
});

function animateRing() {
  rx += (mx - rx) * 0.12;
  ry += (my - ry) * 0.12;
  ring.style.left = rx + 'px'; ring.style.top = ry + 'px';
  requestAnimationFrame(animateRing);
}
animateRing();

document.querySelectorAll('a, button, [onclick]').forEach(el => {
  el.addEventListener('mouseenter', () => document.body.classList.add('cursor-hover'));
  el.addEventListener('mouseleave', () => document.body.classList.remove('cursor-hover'));
});

// ===== PAGE NAV =====
);
  if (push) {
    try { history.pushState(null, '', '#' + name); } catch (e) { location.hash = name; }
  }
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Activate page from URL hash on load (no push)
document.addEventListener('DOMContentLoaded', () => {
  const h = (location.hash || '').replace('#', '');
  if (h) goPage(h, false);

  // Convert inline onclick="goPage('...')" handlers into hash navigation so CTAs are bookmarkable.
  document.querySelectorAll('[onclick]').forEach(el => {
    const attr = el.getAttribute('onclick') || '';
    const m = attr.match(/goPage\('([^']+)'\)/);
    if (m) {
      const name = m[1];
      const callsClose = attr.includes('closeMob()');
      // remove inline handler and replace with a hash-based click handler
      el.removeAttribute('onclick');
      el.addEventListener('click', (e) => {
        location.hash = name;
        if (callsClose && typeof closeMob === 'function') closeMob();
      });
    }
  });
});

// Handle hash changes (back/forward or direct anchor clicks)
window.addEventListener('hashchange', () => {
  const h = (location.hash || '').replace('#', '');
  goPage(h, false);
});

// ===== MOBILE MENU =====
function toggleMob() { document.getElementById('mobMenu').classList.toggle('open'); }
function closeMob() { document.getElementById('mobMenu').classList.remove('open'); }

// ===== SCROLL REVEAL =====
const io = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.style.opacity = '1';
      e.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.08 });

setTimeout(() => {
  document.querySelectorAll('.authority__card, .case-card, .insight-card, .venture-card, .service-row, .process-step, .service-detail-card, .timeline-item').forEach((el, i) => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(24px)';
    el.style.transition = `opacity .6s ease ${i * 0.06}s, transform .6s ease ${i * 0.06}s`;
    io.observe(el);
  });
}, 100);
